"""Core components for twat-genai."""
