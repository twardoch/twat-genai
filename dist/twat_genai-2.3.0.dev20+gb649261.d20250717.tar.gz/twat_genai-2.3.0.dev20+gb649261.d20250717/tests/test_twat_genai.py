"""Test suite for twat_genai."""


def test_version():
    """Verify package exposes version."""
    import twat_genai

    assert twat_genai.__version__
